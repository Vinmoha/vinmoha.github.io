# Vincent Ochieng Odera — Professional Portfolio

Personal portfolio website for Vincent Ochieng Odera.

## Files
- `index.html` — website structure and content
- `style.css` — responsive visual design
- `script.js` — mobile navigation and dynamic year
- `profile-photo.png` — profile image
- `Vincent_Ochieng_Odera_CV.pdf` — downloadable CV

## GitHub Pages
Upload all files to the root of the `vinmoha.github.io` repository. GitHub Pages should then serve the site at the repository's Pages URL.
